<?php 
session_start();
 
include 'koneksi1.php';
 
$username = $_POST['username'];
$password = $_POST['password'];
 
 
$login = mysqli_query($koneksi,"select * from mahasiswa where username='$username' and password='$password'");

$cek = mysqli_num_rows($login);
 
if($cek > 0){
 
	$data = mysqli_fetch_assoc($login);
 
	if($data['level']=="mahasiswa"){
 
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "mahasiswa";
		
		header("Location: ../Data/index.php");
	
	}else{
 
	
		header("location:index.php?pesan=gagal");
	}	
}else{
	header("location:index.php?pesan=gagal");
}
 
?>
